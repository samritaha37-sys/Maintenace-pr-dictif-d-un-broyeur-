"""Pebble mill AI dashboard modules."""
